# megabox2019
megabox site New


<h1>메가박스 사이트 만들기(2019) - 동영상</h1>
<ul>
  <li><a href="https://wtss.tistory.com/280">01. 메가박스 사이트 만들기(2019) - 기본 셋팅</a></li>
  <li><a href="https://wtss.tistory.com/281">02. 메가박스 사이트 만들기(2019) - 헤더 영역</a></li>
  <li><a href="https://wtss.tistory.com/282">03. 메가박스 사이트 만들기(2019) - 배너 영역</a></li>
  <li><a href="https://wtss.tistory.com/283">04. 메가박스 사이트 만들기(2019) - 헤더 반응형 : 모바일 메뉴</a></li>
  <li><a href="https://wtss.tistory.com/284">05. 메가박스 사이트 만들기(2019) - 배너 : Swiper.js</a></li>
  <li><a href="https://wtss.tistory.com/285">06. 메가박스 사이트 만들기(2019) - 배너 반응형</a></li>
  <li><a href="https://wtss.tistory.com/286">07. 메가박스 사이트 만들기(2019) - 영화 차트 구조잡기</a></li>
  <li><a href="https://wtss.tistory.com/287">08. 메가박스 사이트 만들기(2019) - 영화 차트 탭 메뉴</a></li>
  <li><a href="https://wtss.tistory.com/288">09. 메가박스 사이트 만들기(2019) - 영화 차트 이미지 슬라이드</a></li>
  <li><a href="https://wtss.tistory.com/289">10. 메가박스 사이트 만들기(2019) - 영화 차트 이미지 슬라이드 반응형</a></li>
  <li><a href="https://wtss.tistory.com/290">11. 메가박스 사이트 만들기(2019) - 이벤트 영역</a></li>
  <li><a href="https://wtss.tistory.com/291">12. 메가박스 사이트 만들기(2019) - 오프닝 영역</a></li>
  <li><a href="https://wtss.tistory.com/292">13. 메가박스 사이트 만들기(2019) - 새로운 영화 영역</a></li>
  <li><a href="https://wtss.tistory.com/293">14. 메가박스 사이트 만들기(2019) - 새로운 영화 영역2</a></li><br>
  <li><a href="https://wtss.tistory.com/293">14. 메가박스 사이트 만들기(2019) - 유튜브 API 이용하기</a></li>
  <li><a href="https://wtss.tistory.com/294">15. 메가박스 사이트 만들기(2019) - 공지사항 / 탭 메뉴</a></li>
  <li><a href="https://wtss.tistory.com/295">16. 메가박스 사이트 만들기(2019) - 메가박스 할인카드</a></li>
  <li><a href="https://wtss.tistory.com/296">17. 메가박스 사이트 만들기(2019) - 고객센터 / SVG</a></li>
  <li><a href="https://wtss.tistory.com/297">18. 메가박스 사이트 만들기(2019) - 헬프 영역 반응형</a></li>
  <li><a href="https://wtss.tistory.com/298">19. 메가박스 사이트 만들기(2019) - 푸터 영역</a></li>
</ul>





<h1>메가박스 사이트 만들기(2019)</h1>
<ul>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega280_01.html">01. 메가박스 사이트 만들기(2019) - 기본 셋팅</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega281_02.html">02. 메가박스 사이트 만들기(2019) - 헤더 영역</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega282_03.html">03. 메가박스 사이트 만들기(2019) - 배너 영역</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega283_04.html">04. 메가박스 사이트 만들기(2019) - 헤더 반응형 : 모바일 메뉴</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega284_05.html">05. 메가박스 사이트 만들기(2019) - 배너 : Swiper.js</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega285_06.html">06. 메가박스 사이트 만들기(2019) - 배너 반응형</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega286_07.html">07. 메가박스 사이트 만들기(2019) - 영화 차트 구조잡기</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega287_08.html">08. 메가박스 사이트 만들기(2019) - 영화 차트 탭 메뉴</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega288_09.html">09. 메가박스 사이트 만들기(2019) - 영화 차트 이미지 슬라이드</a>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega289_10.html">10. 메가박스 사이트 만들기(2019) - 영화 차트 이미지 슬라이드 반응형</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega290_11.html">11. 메가박스 사이트 만들기(2019) - 이벤트 영역</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega291_12.html">12. 메가박스 사이트 만들기(2019) - 오프닝 영역</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega292_13.html">13. 메가박스 사이트 만들기(2019) - 새로운 영화 영역</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega293_14.html">14. 메가박스 사이트 만들기(2019) - 새로운 영화 영역2</a></li><br>
  
  <li><a href="https://webstoryboy.github.io/megabox2019/mega293_14.html">14. 메가박스 사이트 만들기(2019) - 유튜브 API 이용하기</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega294_15.html">15. 메가박스 사이트 만들기(2019) - 공지사항 / 탭 메뉴</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega295_16.html">16. 메가박스 사이트 만들기(2019) - 메가박스 할인카드</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega296_17.html">17. 메가박스 사이트 만들기(2019) - 고객센터 / SVG</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega297_18.html">18. 메가박스 사이트 만들기(2019) - 헬프 영역 반응형</a></li>
  <li><a href="https://webstoryboy.github.io/megabox2019/mega298_19.html">19. 메가박스 사이트 만들기(2019) - 푸터 영역</a></li>
</ul>
